package Core_java_Task2;

   public class Book {
       private int bookId;
    private String bookName, authorName;
    int getId(){
        return bookId;
    }
    String getName(){
        return bookName;
    }
    String getAuthor(){
        return authorName;
    }
    void setId(int id){
        bookId=id;
    }
    void setBookName(String name){
        bookName=name;
    }
    void setAuthorName(String author){
        authorName=author;
    }
    public String toString(){
        return "Id "+bookId+"Book Name "+bookName+"AuthorName "+authorName;
    }


}
