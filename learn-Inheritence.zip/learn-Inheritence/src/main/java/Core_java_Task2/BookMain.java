package Core_java_Task2;

public class BookMain {
    public static void main(String[] args) {
        Book b=new Book();
        b.setId(101);
        b.setBookName("Green Eggs and Ham");
        b.setAuthorName("Dr.Seuss");
        System.out.println(b.toString());


        Book b1=new Book();
        b1.setId(102);
        b1.setBookName("The Adventures of Huckleberry Finn");
        b1.setAuthorName("Mark Twain");
        System.out.println(b1.toString());

        Book b2=new Book();
        b2.setId(101);
        b2.setBookName("A Tale of Two Cities");
        b2.setAuthorName("Charles Dickens");
        System.out.println(b2.toString());

        Book b3=new Book();
        b3.setId(101);
        b3.setBookName("One Fish, Two Fish, Red Fish, Blue Fish");
        b3.setAuthorName("Dr. Seuss");
        System.out.println(b3.toString());

        Book b4=new Book();
        b4.setId(101);
        b4.setBookName("jack ");
        b4.setAuthorName("Bhanu");
        System.out.println(b4.toString());

        Book b5=new Book();
        b5.setId(101);
        b5.setBookName("Captain America");
        b5.setAuthorName("Chandan");
        System.out.println(b5.toString());

        Book b6=new Book();
        b6.setId(101);
        b6.setBookName("Work in Hard");
        b6.setAuthorName("piyush");
        System.out.println(b6.toString());

        Book b7=new Book();
        b7.setId(101);
        b7.setBookName("Rich dad Poor Dad");
        b7.setAuthorName("Ashish");
        System.out.println(b7.toString());

        Book b8=new Book();
        b8.setId(101);
        b8.setBookName("green day");
        b8.setAuthorName("manish");
        System.out.println(b8.toString());

        Book b9=new Book();
        b9.setId(101);
        b9.setBookName("good Daddy");
        b9.setAuthorName("Ananya");
        System.out.println(b9.toString());






    }
}
