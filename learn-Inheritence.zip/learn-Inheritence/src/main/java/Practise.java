import org.example.First;
public class Practise  {

   public static void work(){

    }

    public static void main(String[] args) {
        String s = "purr";
        System.out.println(s.toUpperCase());
        System.out.println(s);
        s.trim();
        s.substring(1, 3);
        s+=" two";
        System.out.println(s.length());
        System.out.println(s);
    }

}

