package core_java;

public class Address {
    String Floor_number,Street_Name,City_Name,State,Country;


}
