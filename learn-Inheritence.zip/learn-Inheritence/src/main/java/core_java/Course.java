package core_java;

public class Course {
    int Course_Id;
    String Course_Name;
    int Course_Duration;
}
