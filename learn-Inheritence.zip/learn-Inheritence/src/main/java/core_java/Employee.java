package core_java;

public class Employee extends Address{

    int Id;
    String Name;
    double Salary;

    void PrintDetails(){
        System.out.println("Student Id"+Id);
        System.out.println("Student Name"+Name);
        System.out.println("Student Id"+Salary);


    }



}
