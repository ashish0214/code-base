package core_java;

public class Junior_Engineer extends Employee {
    int Assessment_Score;
    String Feedback;
    void details(){

    }
}
