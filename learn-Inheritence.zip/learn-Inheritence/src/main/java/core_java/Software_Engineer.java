package core_java;

public class Software_Engineer extends Employee{
    String Project_Name;

    @Override
    void PrintDetails() {
        super.PrintDetails();
        System.out.println("Project"+Project_Name);
    }
}
