package core_java;

public class Trainer extends Employee{
    String skills;
    String certifications;

    @Override
    void PrintDetails() {
        super.PrintDetails();
        System.out.println("Skills"+skills);
        System.out.println("Certifications"+certifications);
    }
}
