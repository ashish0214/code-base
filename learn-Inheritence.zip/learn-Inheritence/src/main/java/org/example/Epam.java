package org.example;

public class Epam extends Exception{
    String value;
    Epam(String value){
        this.value=value;
    }
    String getData(){
        return value;
    }
}
