package org.example;



public class First {
//exception handling

//    static void display(){
//        display2();
//    }
//static  void display2(){
//        display3();
//    }
//    static void display3(){
//        int a=10/0;
//    }
      void work1()throws  Epam{
        throw new Epam("This is a exception");
    }

    public static void main(String[] args) {
        First f = new First();
try {
    f.work1();
}
catch(Epam e){
    System.out.println(e.getData());
}



}}
