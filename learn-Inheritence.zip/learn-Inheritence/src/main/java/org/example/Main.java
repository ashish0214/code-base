//package org.example;
//
////TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
//// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
//public class Main extends second {
//    void task(){
//        System.out.println("third");
//        super.task();
//        System.out.println(super.job);
//    }
//    public static void main(String[] args) {
//        Main m=new Main();
//        m.task();
//    }
//}