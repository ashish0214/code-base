package org.example;

 public class second {
    final int job=2222;
  static void task(){
        System.out.println("second");


    }
}
