package com.epam.quizApplication.ConsoleUserInterface;


import com.epam.quizApplication.ConsoleUserInterface.userInterface.QuestionOperations;
import com.epam.quizApplication.exceptions.DisplayException;
import com.epam.quizApplication.models.Question;
import com.epam.quizApplication.services.serviceInterface.QuestionService;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.Map;
import java.util.Scanner;

public class DisplayQuestion implements QuestionOperations {
private static final Logger logger= LogManager.getLogger(DisplayQuestion.class);
	@Override
	public void execute(QuestionService questionServices, Scanner scanner)throws DisplayException {
		try {
			Map<Integer, Question> questions = questionServices.questionList();
			questions.entrySet().stream().forEach(entry -> {
				logger.info("Question id :"+entry.getKey());
				Question question1 = entry.getValue();
				logger.info(question1.getQuestion());
				question1.getOptions().forEach(logger::info);
			});
		} catch (DisplayException e) {
			logger.error(e.getMessage());
		}
	}

}
