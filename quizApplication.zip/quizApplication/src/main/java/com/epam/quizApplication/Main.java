package com.epam.quizApplication;

import com.epam.quizApplication.ConsoleUserInterface.QuizManagement;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Main implements CommandLineRunner {
    private static QuizManagement quizManagement;
    private static final Logger log = LogManager.getLogger(Main.class);

    @Autowired
    public Main(QuizManagement quizManagement) {
        this.quizManagement = quizManagement;
    }

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    public void run(String... args) throws Exception {
        quizManagement.quizManagement();
    }

}


