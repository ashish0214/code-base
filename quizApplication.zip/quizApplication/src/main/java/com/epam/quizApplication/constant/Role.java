package com.epam.quizApplication.constant;

public enum Role {
    ADMIN,USER;
}
