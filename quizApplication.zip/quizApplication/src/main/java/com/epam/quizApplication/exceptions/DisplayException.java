package com.epam.quizApplication.exceptions;

public class DisplayException extends RuntimeException{
    public DisplayException(){
        super("Displaying Failed");

    }
}
