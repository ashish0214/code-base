package com.epam.quizApplication.exceptions;

public class QuestionIdNotPresentException extends RuntimeException{

    public QuestionIdNotPresentException(String message){
        super(message);

    }


}
