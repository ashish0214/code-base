package com.epam.quizApplication.exceptions;

public class QuestionIdPresentException extends RuntimeException {

    public QuestionIdPresentException(String message) {
        super(message);
    }
}
