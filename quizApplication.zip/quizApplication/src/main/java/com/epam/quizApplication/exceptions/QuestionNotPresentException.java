package com.epam.quizApplication.exceptions;

public class QuestionNotPresentException extends RuntimeException{
    public QuestionNotPresentException(String message){
        super(message);

    }
}
