package com.epam.quizApplication.exceptions;

public class QuizNameNotPresentException extends RuntimeException{
    public QuizNameNotPresentException(String message){
        super(message);

    }
}
