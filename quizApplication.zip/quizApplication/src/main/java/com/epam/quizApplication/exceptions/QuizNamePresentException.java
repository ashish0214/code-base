package com.epam.quizApplication.exceptions;

public class QuizNamePresentException extends RuntimeException {


    public QuizNamePresentException(String message) {
        super(message);
    }


}
