package com.epam.quizApplication.exceptions;

public class UserNameNotPresentException extends RuntimeException {


    public UserNameNotPresentException(String message) {
        super(message);
    }
}
