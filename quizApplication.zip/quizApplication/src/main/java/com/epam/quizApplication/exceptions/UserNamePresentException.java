package com.epam.quizApplication.exceptions;

public class UserNamePresentException extends RuntimeException{


    public UserNamePresentException(String message) {
        super(message);
    }
}
