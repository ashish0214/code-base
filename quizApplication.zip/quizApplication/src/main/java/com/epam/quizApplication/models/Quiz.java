package com.epam.quizApplication.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

import java.util.List;
import java.util.Objects;
@Entity
public class Quiz {
    @Id
    private String quizTitle;
    private String description;
    @OneToMany
    private List<Integer> questionsNumberList;
    private Integer totalMarks;
}
