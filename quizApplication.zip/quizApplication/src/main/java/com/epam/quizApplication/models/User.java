package com.epam.quizApplication.models;

import com.epam.quizApplication.constant.Role;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.Objects;
@Getter
@Setter
@EqualsAndHashCode
@Entity
public class User {
    @Id
    @Column(name="User")
    private String userName;
    private String password;
    Role role;

}
