package com.epam.quizApplication.repositories;

import com.epam.quizApplication.models.Question;
import org.springframework.data.repository.CrudRepository;

public interface QuestionLibraryDAO extends CrudRepository<Question,Integer> {
}
