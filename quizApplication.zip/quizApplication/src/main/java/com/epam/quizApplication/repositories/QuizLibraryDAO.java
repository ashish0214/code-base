package com.epam.quizApplication.repositories;

import com.epam.quizApplication.models.Quiz;
import org.springframework.data.repository.CrudRepository;

public interface QuizLibraryDAO extends CrudRepository<Quiz,String> {
}
