package com.epam.quizApplication.repositories;

import com.epam.quizApplication.models.User;
import org.springframework.data.repository.CrudRepository;

public interface UserDAO extends CrudRepository<User,String> {
}
