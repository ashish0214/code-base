package com.epam.quizApplication.services;

import com.epam.quizApplication.models.Question;
import com.epam.quizApplication.repositories.QuestionLibraryDAO;
import com.epam.quizApplication.services.serviceInterface.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;

@Component
public class CategoryServiceImple implements CategoryService {
    @Autowired
    QuestionLibraryDAO questionDAO;
    

    public Optional<List<Question>> findBasedOnCategories(String category) {

        try {
            List<Question> questions = questionDAO.getQuestions().values().stream()
                    .filter(question -> question.getCategory().equalsIgnoreCase(category))
                    .toList();

            if (!questions.isEmpty()) {
                return Optional.of(questions);
            } else {
                return Optional.empty();
            }
        } catch (NullPointerException e) {
            return Optional.empty();
        }

    }


}
