package com.epam.quizApplication.services;

import com.epam.quizApplication.exceptions.QuestionIdNotPresentException;
import com.epam.quizApplication.exceptions.QuestionIdPresentException;
import com.epam.quizApplication.exceptions.QuestionNotPresentException;
import com.epam.quizApplication.models.Question;
import com.epam.quizApplication.repositories.QuestionLibraryDAO;
import com.epam.quizApplication.services.serviceInterface.QuestionService;
import com.epam.quizApplication.services.serviceInterface.QuestionValidate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;
@Component
public class QuestionServicesImple implements QuestionService {
    @Autowired
    QuestionLibraryDAO questionDAO ;
    @Autowired
    QuestionValidate questionValidator ;


    public QuestionServicesImple(){
    }

    public String createQuestion(int id, Question question) throws QuestionIdPresentException {
        if (questionValidation(question)) {
            Optional<Question> questionExists = questionDAO.findById(id);

                questionExists.ifPresentOrElse(question1 -> {
                    throw new QuestionIdPresentException("Question id already present");
                }, () -> questionDAO.save(question));

            return "Successfully Question created";
        }
        return "Question invalid";
    }

    @Override
    public String updateQuestion(int id, Question newQuestion) throws QuestionIdNotPresentException {

        Optional<Question> questionExists = questionDAO.findById(id);

        questionExists.ifPresentOrElse(question -> questionDAO.save( newQuestion), () -> {
            throw new QuestionIdNotPresentException("Id not present to modify");
        });

        return "Successfully modified the question";
    }

    @Override
    public String deleteQuestion(int id) throws QuestionIdNotPresentException {

        Optional<Question> questionExists = questionDAO.findById(id);

        questionExists.ifPresentOrElse(question -> questionDAO.delete(question), () -> {
            throw new QuestionIdNotPresentException("id not present to remove");
        });
        return "Successfully deleted question";
    }


    public Map<Integer, Question> questionList() throws QuestionNotPresentException {
        Map<Integer, Question> questionPresent;

        if (getNumberOfQuestionPresent() > 0) {
            questionPresent = questionDAO.findAll();
        } else {
            throw new QuestionNotPresentException("No Question Present");
        }
        return questionPresent;
    }

//not tested
    public Optional<Question> findById(int id) {
        return questionDAO.getQuestions().entrySet().stream().filter(element -> element.getKey() == id).map(entry->entry.getValue()).findAny();
    }


    public Integer getNumberOfQuestionPresent() {
        return questionDAO.getQuestions().size();
    }


    boolean questionValidation(Question question) {
        return questionValidator.validateQuestion(question);
    }


}
