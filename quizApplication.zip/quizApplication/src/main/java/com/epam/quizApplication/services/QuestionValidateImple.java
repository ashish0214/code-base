package com.epam.quizApplication.services;

import com.epam.quizApplication.models.Question;
import com.epam.quizApplication.services.serviceInterface.QuestionValidate;
import org.springframework.stereotype.Component;

@Component
public class QuestionValidateImple implements QuestionValidate {

    public boolean validateQuestion(Question question) {
        return validateQuestionStatement(question) && validateOptions(question) && validateCorrectOption(question);
    }

    boolean validateQuestionStatement(Question question) {
        return question.getQuestion().length() >= 10;
    }

     boolean validateOptions(Question question) {
        return question.getOptions().size() >= 4;
    }

    boolean validateCorrectOption(Question question) {
        return !question.getCorrectOption().isEmpty();
    }


}
