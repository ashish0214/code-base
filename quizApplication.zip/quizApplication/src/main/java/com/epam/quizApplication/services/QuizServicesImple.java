package com.epam.quizApplication.services;

import com.epam.quizApplication.exceptions.QuizNameNotPresentException;
import com.epam.quizApplication.exceptions.QuizNamePresentException;
import com.epam.quizApplication.models.Quiz;
import com.epam.quizApplication.repositories.QuizLibraryDAO;
import com.epam.quizApplication.services.serviceInterface.QuizService;
import com.epam.quizApplication.services.serviceInterface.QuizValidate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
@Component
public class QuizServicesImple implements QuizService {
    @Autowired
    public QuizLibraryDAO quizLibraryDAO;
    @Autowired
    public QuizValidate quizValidator;

    @Override
    public String createQuiz(String quizName, Quiz quiz) throws QuizNamePresentException {
        Optional<String>checkQuizNameNotNull=Optional.ofNullable(quizName);
        if(checkQuizNameNotNull.isPresent()) {
            Optional<Map.Entry<String,Quiz>>checkSameQuizAvailable=quizLibraryDAO.getQuizzes().entrySet().stream().filter(element->element.getKey().equalsIgnoreCase(quizName)).findAny();
                    checkSameQuizAvailable.ifPresentOrElse(element -> {
                        throw new QuizNamePresentException("QuizName present");
                    }, () -> quizLibraryDAO.addQuiz(quizName, quiz));
        }
        return "Successfully quiz added";
    }

    @Override
    public String updateQuiz(String quizName, Quiz quiz) throws QuizNameNotPresentException {
        Optional<String>checkQuizNameNotNull=Optional.ofNullable(quizName);
        if(checkQuizNameNotNull.isPresent()) {
            Optional<Map.Entry<String, Quiz>> checkSameQuizAvailable = quizLibraryDAO.getQuizzes().entrySet().stream().filter(element -> element.getKey().equalsIgnoreCase(quizName)).findAny();
            checkSameQuizAvailable.ifPresentOrElse(element -> quizLibraryDAO.modifyQuiz(quizName, quiz),
                    () -> {
                        throw new QuizNameNotPresentException("QuizName not present");
                    });


        }
        return "Successfully Quiz modifed";

    }

    @Override
    public String removeQuiz(String quizName) throws QuizNameNotPresentException {
        Optional<String>checkQuizNameNotNull=Optional.ofNullable(quizName);
        if(checkQuizNameNotNull.isPresent()) {
            Optional<Map.Entry<String, Quiz>> checkSameQuizAvailable = quizLibraryDAO.getQuizzes().entrySet().stream().filter(element -> element.getKey().equalsIgnoreCase(quizName)).findAny();
                    checkSameQuizAvailable.ifPresentOrElse(element -> quizLibraryDAO.removeQuiz(quizName),
                            () -> {
                                throw new QuizNameNotPresentException("Quiz not found");
                            });
        }
        return "Successfully quiz removal";
    }

    @Override
    public Optional<Quiz> findQuiz(String quizName) {
        return quizLibraryDAO.getQuizzes().entrySet().stream().filter(element -> element.getKey().equalsIgnoreCase(quizName)).map(Map.Entry::getValue).findAny();
    }

    public List<Quiz> findAllQuiz() {
        return quizLibraryDAO.getQuizzes().entrySet().stream().map(Map.Entry::getValue).collect(Collectors.toList());
    }


    public boolean isQuizNamePresent(String quizName) {
        return quizLibraryDAO.getQuizzes().containsKey(quizName);
    }

    public boolean validateQuiz(Quiz quiz, String quizName) {
        return isQuizNamePresent(quizName) && quizValidator.validateQuiz(quizName, quiz);
    }


}
