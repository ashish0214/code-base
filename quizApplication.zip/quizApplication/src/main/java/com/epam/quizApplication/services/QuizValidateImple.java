package com.epam.quizApplication.services;

import com.epam.quizApplication.models.Quiz;
import com.epam.quizApplication.services.serviceInterface.QuizValidate;
import org.springframework.stereotype.Component;

@Component
public class QuizValidateImple implements QuizValidate {

    public boolean validateQuiz(String quizName, Quiz quiz) {
        return validateNumberOfQuestionInAQuiz(quiz) && validateDescription(quiz);
    }

    public boolean validateNumberOfQuestionInAQuiz( Quiz quiz) {
        return quiz.getQuestionsNumberList().size() >= 10;
    }

    public boolean validateDescription(Quiz quiz) {
        return quiz.getDescription().length() > 20;
    }

}
