package com.epam.quizApplication.services;


import com.epam.quizApplication.exceptions.UserNameNotPresentException;
import com.epam.quizApplication.exceptions.UserNamePresentException;
import com.epam.quizApplication.models.User;
import com.epam.quizApplication.repositories.UserDAO;
import com.epam.quizApplication.services.serviceInterface.UserServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class UserServicesImple implements UserServices {

    UserDAO userDao;
    @Autowired
    public  UserServicesImple(UserDAO userDAOImple){
        this.userDao=userDAOImple;
    }

    public void creatUser(User user) throws UserNamePresentException {
        if (isUserNamePresent(user)) {
            throw new UserNamePresentException("Enter Different username");
        } else {
            userDao.save(user);
        }

    }

    public void deleteUser(User user) throws UserNameNotPresentException {

        if (isUserNamePresent(user)) {
            userDao.delete(user);
        } else {
            throw new UserNameNotPresentException("No User Present to remove");
        }
    }


    public boolean validate(String username, String password) {
        return userDao.getUsers().stream()
                .anyMatch(user -> username.equals(user.getUserName()) && password.equals(user.getPassword()));
    }
    public Set<User> getUsers(){
        return userDao.getUsers();
    }


    boolean isUserNamePresent(User user) {
        return userDao.getUsers().contains(user);
    }
}
