package com.epam.quizApplication.services.serviceInterface;

import com.epam.quizApplication.models.Question;

import java.util.List;
import java.util.Optional;

public interface CategoryService {
    Optional<List<Question>> findBasedOnCategories(String category);
}
