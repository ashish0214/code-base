package com.epam.quizApplication.services.serviceInterface;

import com.epam.quizApplication.models.Question;

import java.util.Map;
import java.util.Optional;

public interface QuestionService {
    String createQuestion(int id, Question question);

    String updateQuestion(int id, Question newQuestion);

    String deleteQuestion(int id) ;

    Map<Integer, Question> questionList();

    Optional<Question> findById(int id);

    Integer getNumberOfQuestionPresent();
}
