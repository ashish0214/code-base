package com.epam.quizApplication.services.serviceInterface;

import com.epam.quizApplication.models.Question;

public interface QuestionValidate {
    public boolean validateQuestion(Question question);
}
