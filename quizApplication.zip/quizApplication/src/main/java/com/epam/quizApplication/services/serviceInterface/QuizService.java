package com.epam.quizApplication.services.serviceInterface;


import com.epam.quizApplication.models.Quiz;

import java.util.List;
import java.util.Optional;

public interface QuizService {
    String createQuiz(String quizName,Quiz quiz);
    String updateQuiz(String quizName,Quiz quiz) ;
    String removeQuiz(String quizName) ;
    Optional<Quiz> findQuiz(String quizName);
    List<Quiz> findAllQuiz();
}
