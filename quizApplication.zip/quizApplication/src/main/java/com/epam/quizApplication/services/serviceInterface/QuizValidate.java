package com.epam.quizApplication.services.serviceInterface;

import com.epam.quizApplication.models.Quiz;

public interface QuizValidate {
    boolean validateQuiz(String quizName,Quiz quiz);
    boolean validateNumberOfQuestionInAQuiz( Quiz quiz);
    boolean validateDescription(Quiz quiz);
}
