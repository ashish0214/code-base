package com.epam.quizApplication.services.serviceInterface;

import com.epam.quizApplication.models.User;

public interface UserServices {
    void creatUser(User user);
    void deleteUser(User user);
    boolean validate(String username, String password);
}
